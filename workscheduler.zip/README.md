
- make sure you have python3

- then open cmd `sudo apt-get install python3-pyqt5`

- `python3 gui.py` you are good to go


#todos
- show relationship between client and teammates
- make the output looks like calender
- make the number of days configurable
- improve code quality